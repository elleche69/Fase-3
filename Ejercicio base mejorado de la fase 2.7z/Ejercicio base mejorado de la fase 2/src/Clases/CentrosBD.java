


package Clases;

import java.util.ArrayList;
import java.sql.*;



public class CentrosBD extends GenericBD{
    
    private static ArrayList<Centros> centros;
    
    public static ArrayList<Centros> Introducir_datos_en_combo(){
    
       try{
           Centros centro;
           
           GenerarConexion();          
           centros = new ArrayList();          
           String lista = "Select id, nombre from CENTROSBD";          
           PreparedStatement ps = GenericBD.getCon().prepareStatement(lista);
           ResultSet resultado = ps.executeQuery();
           
           
           
           while(resultado.next()){
           
               centro = new Centros(Integer.parseInt(resultado.getString("ID")),resultado.getString("NOMBRE"));
               centros.add(centro);
               System.out.print(centro.getId());
           
           }
           
           return centros;
           
        }   
           
        catch(Exception e){return null;}
        
        finally{
         
           cerrarConexion();
       
       }    
        
       
    
       
        
            
        
       
       
       
      
       
       
       
       
       
       
       
       
    
        
    
    }
    
    
    
    
    
    
    
    
    
}
