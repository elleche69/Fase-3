/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import Clases.Trabajadores;
import Excepciones.Campo_obligatorio_sin_patron_vacio;
import Excepciones.Nombres_mal;
import Excepciones.Portal_malo;
import Excepciones.Sueldo_Incorrecto;
import Excepciones.Telefono_Mal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.Timer;

/**
 *
 * @author itziar
 */
public class CRUDTrabajadores extends javax.swing.JFrame {

    /**
     * Creates new form CRUDTrabajadores
     */
    public CRUDTrabajadores() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel12 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        on = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        tf_calle = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tf_portal = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tf_piso = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tf_mano = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        tf_dni = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        tf_telmov = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tf_telper = new javax.swing.JTextField();
        tf_nombre = new javax.swing.JTextField();
        tf_apellido1 = new javax.swing.JTextField();
        tf_apellido2 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        log = new javax.swing.JRadioButton();
        admin = new javax.swing.JRadioButton();
        jLabel13 = new javax.swing.JLabel();
        tf_sal = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        tf_nacim = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        jLabel12.setText("jLabel12");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("DATOS DEL TRABAJADOR");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("DNI:");

        on.setText("ON");
        on.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 255)), "DIRECCION", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Calle:");

        tf_calle.setEnabled(false);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Portal");

        tf_portal.setEnabled(false);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Piso");

        tf_piso.setEnabled(false);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Mano");

        tf_mano.setEnabled(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(tf_portal, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(76, 76, 76)
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(tf_piso, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(tf_mano, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(67, 67, 67)
                        .addComponent(tf_calle, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tf_calle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tf_portal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(tf_piso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(tf_mano, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Nombre");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Apellido");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Apellido2");

        tf_dni.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tf_dniFocusLost(evt);
            }
        });
        tf_dni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tf_dniKeyPressed(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 255)), "TELEFONOS", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Telefono movil");

        tf_telmov.setEnabled(false);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Telefono personal");

        tf_telper.setEnabled(false);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10))
                .addGap(55, 55, 55)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tf_telmov, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                    .addComponent(tf_telper))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tf_telmov, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(tf_telper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tf_nombre.setEnabled(false);

        tf_apellido1.setEnabled(false);

        tf_apellido2.setEnabled(false);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 51, 255)), "TIPO", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        log.setText("Logistica");
        log.setEnabled(false);
        log.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logActionPerformed(evt);
            }
        });

        admin.setText("Administracion");
        admin.setEnabled(false);
        admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(admin)
                    .addComponent(log))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(log)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addComponent(admin)
                .addGap(39, 39, 39))
        );

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Salario");

        tf_sal.setEnabled(false);

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("Fecha nacimiento");

        tf_nacim.setEnabled(false);

        jButton1.setText("Aceptar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Salir");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14))
                        .addGap(61, 61, 61)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tf_sal, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                            .addComponent(tf_nacim)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2)))))
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(150, 150, 150)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 252, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(tf_apellido2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                                        .addComponent(tf_apellido1, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tf_nombre, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tf_dni, javax.swing.GroupLayout.Alignment.LEADING))
                                    .addGap(14, 14, 14)
                                    .addComponent(on)
                                    .addGap(18, 18, 18)
                                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(17, 17, 17)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(33, 33, 33)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 370, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(tf_sal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(tf_nacim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(39, 39, 39))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(78, 78, 78)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(tf_dni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(on))
                            .addGap(18, 18, 18)
                            .addComponent(tf_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(tf_apellido1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(tf_apellido2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(40, 40, 40))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(18, 18, 18)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(188, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void onActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_onActionPerformed
      

    }//GEN-LAST:event_onActionPerformed

    private void tf_dniFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tf_dniFocusLost

    }//GEN-LAST:event_tf_dniFocusLost

    private void tf_dniKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_dniKeyPressed
        n = 0;
    }//GEN-LAST:event_tf_dniKeyPressed

    private void logActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logActionPerformed
       tipo = "L";
    }//GEN-LAST:event_logActionPerformed

    private void adminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminActionPerformed
        tipo = "A";
    }//GEN-LAST:event_adminActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
                        
        Pasar_Datos();
        EleccionDeLaAccion();
        Vaciado_de_campos();
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.EleccionGenerarVentanas(1, 3);
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.ConseguirIdsDeLaBase(1);
               
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.EleccionGenerarVentanas(1, 3);
        ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.ConseguirIdsDeLaBase(1);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        timer.start();
    }//GEN-LAST:event_formWindowActivated

    
    public void PasarIndexOpcion(int n){        
        index = n;
    }
    
    public void EleccionDeLaAccion(){    
        switch (index){        
            case 1:
                ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.Modificar(data);
                break;                
            case 2:
                ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.Añadir(data);
                break;                
            case 3:
                 ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.Borrar(data.get(0));
                break;
        }}
        
    //METODOS RELATIVOS A LOS TEXTAREAS
    
    public void Enseñar_Datos(Trabajadores trabajador){        
        tf_nombre.setText(trabajador.getNombre());
        tf_apellido1.setText(trabajador.getApellido1());
        tf_apellido2.setText(trabajador.getApellido2());
        tf_calle.setText(trabajador.getCalle());
        tf_portal.setText(trabajador.getPortal());
        tf_piso.setText(trabajador.getPiso() + "");
        tf_mano.setText(trabajador.getMano()+"");
        tf_telmov.setText(trabajador.getTelefono1()+"");
        tf_telper.setText(trabajador.getTelefono2()+"");
        tf_sal.setText(trabajador.getSalario() + "");
    
    }
        
    
    public void Pasar_Datos(){             
        data = new ArrayList();
        data.add(tf_dni.getText());
        data.add(tf_nombre.getText());
        data.add(tf_apellido1.getText());
        data.add(tf_apellido2.getText());
        data.add(tf_calle.getText());
        data.add(tf_piso.getText());        
        data.add(tf_portal.getText());
        data.add(tf_mano.getText());
        data.add(tf_telmov.getText());
        data.add(tf_telper.getText());
        data.add(tf_sal.getText());
        data.add(tf_nacim.getText());
        data.add(tipo);}
    
    
    public void Habilitar_campos(boolean b){    
        tf_nombre.setEnabled(b);
        tf_apellido1.setEnabled(b);
        tf_apellido2.setEnabled(b);
        tf_calle.setEnabled(b);
        tf_portal.setEnabled(b);
        tf_piso.setEnabled(b);
        tf_mano.setEnabled(b);
        tf_telmov.setEnabled(b);
        tf_telper.setEnabled(b);
        tf_sal.setEnabled(b);
        tf_nacim.setEnabled(b);
        log.setEnabled(b);
        log.setSelected(true);
        admin.setEnabled(b);
    }    
        
      public void Vaciado_de_campos(){
        tf_dni.setText(null);
        tf_nombre.setText(null);
        tf_apellido1.setText(null);
        tf_apellido2.setText(null);
        tf_calle.setText(null);
        tf_portal.setText(null);
        tf_piso.setText(null);
        tf_mano.setText(null);
        tf_telmov.setText(null);
        tf_telper.setText(null);
        tf_sal.setText(null);
        tf_nacim.setText(null);
    }        
        
     
    //FINAL DE ESTE TIPO DE METODOS
    
    
    
    
    
    
    
    
    //METODOS DE VALIDACION DE DATOS
            
     private boolean Validar_Nombres(String el_nombre){    
        boolean bole = false;    
        Matcher mat = patron_nombres.matcher(el_nombre);        
        if(mat.matches()){bole = true;}            
        return bole;           
    }    
            
    private boolean Validar_Portal(String portal){    
        boolean bole = false;        
        Matcher mat = patron_portal.matcher(portal);        
        if(mat.matches()){bole = true;}    
        return bole;
    }
    
    private boolean Validar_Telefono(String telefono){
        boolean bole = false;
        Matcher mat = patron_telefonos.matcher(telefono);
        if(mat.matches()){bole = true;}
        return bole;    
    }
    
    
      private void Validar_Todo(){
        //METODO VALIDAR GORDO DEL PELOTON
        int contador = 0;
            try{
                //Validar nombre
                if(Validar_Nombres(tf_nombre.getText()) == true){
                    contador = contador + 1;}                                                            
                else{throw new Nombres_mal(contador);}
                //Validar apellido1
                if(Validar_Nombres(tf_apellido1.getText()) == true){
                    contador = contador + 1;} 
                else{throw new Nombres_mal(contador);}   
                //Validar apellido2
                if(Validar_Nombres(tf_apellido2.getText()) == true){
                    contador = contador + 1;} 
                else{throw new Nombres_mal(contador);}   
                //Validar calle
                if(Validar_Nombres(tf_calle.getText()) == true){
                    contador = contador + 1;} 
                else{throw new Nombres_mal(contador);}   
                //Validar portal
                if(Validar_Portal(tf_portal.getText()) == true){}
                else{throw new Portal_malo();}
                //Validar que "mano" no este vacia
                if(tf_mano.getText().isEmpty()){throw new Campo_obligatorio_sin_patron_vacio();}
                else{}    
                //Validar el telefono personal
                if(tf_telper.getText().isEmpty()){}
                else{
                    if(Validar_Telefono(tf_telper.getText())== true ){}
                    else{throw new Telefono_Mal();}
                }
                //Validar el telefono de la empresa(Este si es obligatorio)                        
                if(Validar_Telefono(tf_telmov.getText()) == true){}
                else{throw new Telefono_Mal();}
                //Validar que en el piso me han metido un numero                
                contador = contador + 1;
                //Controlar que no nos metan numero negativos ni letras en el sueldo
                if(tf_sal.getText().isEmpty()){                   
                }
                else{
                    float y = Float.parseFloat(tf_sal.getText());
                    if(y < 0 ||  y > 10000000){throw new Sueldo_Incorrecto();}} 
                              
                jButton1.setEnabled(true);
            }

            catch(Nombres_mal e){}   

            catch(Portal_malo e){javax.swing.JOptionPane.showMessageDialog(this, "Portal incorrecto");}    

            catch(Campo_obligatorio_sin_patron_vacio e){javax.swing.JOptionPane.showMessageDialog(this, "La mano es obligatoria");}

            catch(Telefono_Mal e){javax.swing.JOptionPane.showMessageDialog(this, "Telefono no valido");}

            catch(Sueldo_Incorrecto e){javax.swing.JOptionPane.showMessageDialog(this, "Sueldo no valido");}

            catch(NumberFormatException e){
                if(contador == 5){
                    javax.swing.JOptionPane.showMessageDialog(this, "Sueldo no valido");}
                 else{
                    javax.swing.JOptionPane.showMessageDialog(this, "Piso no valido");}
            }    
        }
    
//FINAL METODOS VALIDAR    
    
    
//TIMER    
     public Timer timer = new Timer (1000, new ActionListener ()
     {   
        public void actionPerformed(ActionEvent e)
        {
                        
            Pattern pat = Pattern.compile("^[0-9]{8}[A-Za-z]{1}$");
            
            Matcher mat = pat.matcher(tf_dni.getText());
            
            if(mat.matches() && n == 0 ){
                if(index != 2){
                    ejercicio.entorno.programacion.v2.EjercicioEntornoProgramacionV2.Validar_Dato_Introducido(tf_dni.getText());
                    n = n + 1;
                }
                else{
                    
                    
                    Habilitar_campos(true);}
                
            }    
                        
            else{
                
                if(!mat.matches()){
                    
                    n = 0;                   
                }
                else{}
                
            }
        }    
        
    }); 
    
    
    
//TIMER    
    
    
    
    
    
    
    
    
    
      
      
      
      
      
      
      
      
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CRUDTrabajadores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CRUDTrabajadores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CRUDTrabajadores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CRUDTrabajadores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CRUDTrabajadores().setVisible(true);
            }
        });
    }
    private static int n = 0;
    private ArrayList<String> data;
    private int index;
    private String tipo = "L";
    private final Pattern patron_correo_elect = Pattern.compile("^[A-Za-z0-9]+@[A-Za-z0-9].com$");
    private final Pattern patron_portal = Pattern.compile("^[A-Za-z]*[0-9]+[A-Za-z]*$");
    private final Pattern patron_nombres = Pattern.compile("^[A-Za-z]+$");
    private final Pattern patron_telefonos = Pattern.compile("^[0-9]{9}$");
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton admin;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton log;
    private javax.swing.JButton on;
    private javax.swing.JTextField tf_apellido1;
    private javax.swing.JTextField tf_apellido2;
    private javax.swing.JTextField tf_calle;
    private javax.swing.JTextField tf_dni;
    private javax.swing.JTextField tf_mano;
    private javax.swing.JTextField tf_nacim;
    private javax.swing.JTextField tf_nombre;
    private javax.swing.JTextField tf_piso;
    private javax.swing.JTextField tf_portal;
    private javax.swing.JTextField tf_sal;
    private javax.swing.JTextField tf_telmov;
    private javax.swing.JTextField tf_telper;
    // End of variables declaration//GEN-END:variables
}
