




package ejercicio.entorno.programacion.v2;
import Ventanas.*;
import Clases.*;
import Excepciones.*;
import java.util.ArrayList;





public class EjercicioEntornoProgramacionV2 {

    private static VentanaInicio ventana_inicio;
    private static MenuCentros menu_centros;
    private static MenuTrabajadores menu_trabajadores;
    private static CRUDCentros crud_centros;
    private static CRUDTrabajadores crud_trabajadores;
    private static ArrayList<Centros> centros; 
    private static int centro_index_seleccionado; 
    private static Trabajadores trabajador; 
    private static Centros centro; 
    private static int opcion; 
    private static VisualizarTrabPorCentros visualizar;
    public static void main(String[] args) {
        
        EleccionGenerarVentanas(0,1);
        
        
    }
    
    
  
    
    
//METODOS GENERAR VENTANAS    
    
    
    public static void EleccionGenerarVentanas(int b, int n){
    
        switch (n){
        
            case 1:               
                GenerarVentanaPrincipal(b);
                break;                       
            case 2:
                GenerarMenuCentros(b);
                break;                            
            case 3:                             
                GenerarMenuTrabajadores(b);  
                break;            
            case 4:  
                GenerarCrudCentros();
                break;                
            case 5: 
                GenerarCrudTrabajadores();
                break;
            case 6: 
                GenerarTabla();
                break;
                    
        }        
    }            
               
                
    public static void GenerarVentanaPrincipal(int b){          
        switch (b){
            case 1:
                menu_centros.dispose();
                break;
            case 2: 
                menu_trabajadores.dispose();
                break;}            
        ventana_inicio = new VentanaInicio();
        ventana_inicio.setVisible(true);
    }     
        
        
       
    public static void GenerarMenuCentros(int b){    
        if(b == 1){
            crud_centros.dispose();}
        else{
            if(b ==2){visualizar.dispose();}
            else{ ventana_inicio.dispose();}
        }  
        
        
        
        menu_centros = new MenuCentros();
        menu_centros.setVisible(true);
    }    
    
    
        
    public static void GenerarMenuTrabajadores(int b){    
        if (b == 1){
            crud_trabajadores.dispose();}        
        else{ventana_inicio.dispose();}                
        menu_trabajadores = new MenuTrabajadores();
        menu_trabajadores.setVisible(true);
    
    }
    
    
    public static void GenerarCrudCentros(){
        menu_centros.dispose();        
        crud_centros = new CRUDCentros();
        crud_centros.setVisible(true);
    }
    
    public static void GenerarCrudTrabajadores(){
        menu_trabajadores.dispose();
        crud_trabajadores = new CRUDTrabajadores();
        crud_trabajadores.setVisible(true);
    }
    
    
    public static void GenerarTabla(){
    
        menu_centros.dispose();
        visualizar = new VisualizarTrabPorCentros();
        visualizar.setVisible(true);
    
    
    }
    
//FINAL METODOS GENERAR VENTANAS    
    
    
//METODOS RELATIVOS A MENUS    
    public static void ConseguirIdsDeLaBase(int g){                      
        centros = CentrosBD.Introducir_datos_en_combo();
        
        if(g == 1){ menu_trabajadores.RecuperarDatosIds(centros);}
        else{menu_centros.RecuperarDatosDeLaBase(centros);} 
    }        
            
        
          
        
        
    
    
    
    public static void ConseguirCentroSeleccionado(int id){
    
        centro_index_seleccionado = id;        
    }
    
    
    public static void ConseguirOpcion(int n){  
        opcion = n;
        crud_trabajadores.PasarIndexOpcion(n);    
    }
    
    
//FIN DE LOS METODOS DE ESTE TIPO   
    
    
  
//LLAMADA A METODOS "CRUD" TRABAJADORES
       
    public static void Modificar(ArrayList<String> data){
    
        int cx = 0;        
        while(centros.get(cx).getId() != centro_index_seleccionado){        
            cx = cx + 1;        
        }        
        centro = centros.get(cx);        
        trabajador = new Trabajadores(data.get(0),data.get(1),data.get(2),data.get(3),data.get(4), data.get(5),Integer.parseInt(data.get(6)), data.get(7), data.get(8), data.get(9), Integer.parseInt(data.get(10)),data.get(11), centro, data.get(12));        
        Clases.TrabajadoresBD.Modificar_datos(trabajador);    
    }  
           
    
    public static void Añadir(ArrayList<String> data){
    
        if(Clases.TrabajadoresBD.Comprobar(data.get(0)) == true){
           
            int cx = 0;        
            while(centros.get(cx).getId() != centro_index_seleccionado){        
            cx = cx + 1;}  
            centro = centros.get(cx);   
            trabajador = new Trabajadores(data.get(0),data.get(1),data.get(2),data.get(3),data.get(4), data.get(5),Integer.parseInt(data.get(6)), data.get(7), data.get(8), data.get(9), Integer.parseInt(data.get(10)),data.get(11), centro, data.get(12));        
            
            Clases.TrabajadoresBD.Añadir_Nuevo(trabajador);           
       }
    }
        
           
    public static void Borrar(String dna){
    
        Clases.TrabajadoresBD.Borrar_Datos(dna);
   } 
    
//FIN DE METODOS CRUD TRABAJADORES    
    
    
    
    
   public static void Validar_Dato_Introducido(String dna){
   
       trabajador  = TrabajadoresBD.Validar_Trabajadores(dna, centro_index_seleccionado);
   
         if(trabajador != null && opcion == 1){
           
           crud_trabajadores.Habilitar_campos(true);
           crud_trabajadores.Enseñar_Datos(trabajador);
        }   
           
        else{
       
           if(trabajador != null && opcion != 1){
           
               crud_trabajadores.Habilitar_campos(false);
               crud_trabajadores.Enseñar_Datos(trabajador);
           }    
               
           else{
           
                try{
               
                   throw new No_Encontrado();
                }
               
               catch(No_Encontrado e){javax.swing.JOptionPane.showMessageDialog(null, "Trabajador no encontrado");}
            }
        }      
   
   
   
   }
    
    
    
    
    
    
    
//METODOS RELATIVOS A LOS CENTROS
   
   public static void RecojerOpcionEscogida(int h){      
       opcion = h;
       if (opcion != 1 && opcion != 4){
           crud_centros.RecogerCentro(centros.get(menu_centros.PasarIndex()), opcion);}
       else{
       
           if(opcion != 4){crud_centros.RecogerCentro(null, opcion);}
           
           else{visualizar.EnseñarDatos(CentrosBD.VisualizarTrabajadoresCentro(menu_centros.PasarIndex()));}
        }       
    }           
           
       
    public static void CargaADemanda(int id, ArrayList<Trabajadores> trab){
    
       int n = 0;
        
        while (n < centros.size() && centros.get(n).getId() != id){
        
            n = n + 1;
        } 
        
        centros.get(n).setTrabajadores(trab);
       
    
    
    }   
       
            
        
           
    public static boolean ComprobarIdCentroNuevo(int id_nuevo){
    
        boolean b = false;
    
        int n = 0;
        
        while(n < centros.size()){        
            if (id_nuevo == centros.get(n).getId()){
                n = centros.size();
                b = true;}
            else{n = n + 1;}
        }       
        return b;    
    }        
        
    public static void FinalizarAccion(int eleccion, ArrayList<String> data){
        if (eleccion != 3){
            Centros centrox = new Centros(Integer.parseInt(data.get(0)), data.get(1), data.get(2), Integer.parseInt(data.get(3)), data.get(4), data.get(5), data.get(6), data.get(7));
            if(eleccion == 1){
                CentrosBD.AñadirCentro(centrox);
            }
            else{CentrosBD.ModificarCentro(centrox);}        
        }
        else{CentrosBD.EliminarCentro(Integer.parseInt(data.get(0)));}
    
    }
    
        
           
           
    
    
    
    
    
    
    
    
    
    
    }   
    
   
   
   
   
   
    
    
    
    

