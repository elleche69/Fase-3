



package Excepciones;





public class Portal_malo extends Exception{

    public Portal_malo() {
    }
    
    
    
    
}
