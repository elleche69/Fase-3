

package Clases;

import java.util.ArrayList;



public class Centros {
    
    private int id;
    
    private String nombre;
    
    private String calle;
    
    private int numero;
    
    private String codigo;
    
    private String ciudad;
    
    private String provincia;
    
    private String telefono;
    
    private ArrayList<Trabajadores> trabajadores;
    

    public Centros(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Centros(int id, String nombre, String calle, int numero, String codigo, String ciudad, String provincia, String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.calle = calle;
        this.numero = numero;
        this.codigo = codigo;
        this.ciudad = ciudad;
        this.provincia = provincia;
        this.telefono = telefono;
    }
 
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public ArrayList<Trabajadores> getTrabajadores() {
        return trabajadores;
    }

    public void setTrabajadores(ArrayList<Trabajadores> trabajadores) {
        if (this.getTrabajadores() == null){this.trabajadores = trabajadores;}
        else{}
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
